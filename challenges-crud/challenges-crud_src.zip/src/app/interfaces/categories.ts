export const CATEGORIES = [ //FIXME: imageUrl gebruik ik nu niet meer (check if save to delete)
    {name: "meat, fish", imageUrl: "art6.png", icon: "fa fa-hamburger", color: "#ed8e5d"},
    {name: "egg, dairy", imageUrl: "art10.png", icon: "fa fa-cheese", color:"#e9a37f"},
    {name: "fashion", imageUrl: "art4.png", icon: "fa fa-tshirt", color:"#f7c8ad"},
    {name: "personal care", imageUrl: "art5.png", icon: "fa fa-soap", color: "#d08b68"},
    {name: "transportation", imageUrl: "art9.png", icon: "fa fa-bicycle", color: "#dcac94" },
    {name: "other", imageUrl: "art9.png", icon: "fa fa-question", color: "#f3dacc"}
]