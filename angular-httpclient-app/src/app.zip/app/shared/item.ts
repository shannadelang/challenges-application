export interface Item {
id: string;
   name: string;
   email: string;
   phone: number;

}
